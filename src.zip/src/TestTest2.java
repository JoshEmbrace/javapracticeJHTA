
public class TestTest2 {

	public static void main(String[] args) {
//
//		char a = 'A'; //character������ �־ println�� ����ص� ����ȭ �� ���ڰ� �ƴ϶� ���ڷ� ��� �ȴ�
//		
//		while(a <= 90) {
//			
//			System.out.println(a++);
//			
//		}
//
//	}

//	public static void main(String[] args){
//
//		  char a;
//		  a = 'A';
//		  
//		  
//		  while( a <= 90 ){
//		    System.out.write(a++);
//		    System.out.flush();
//		  }
//		int a = 'A';
//		
//		while( a <= 90 ) {
//			
//			System.out.write(a++);
//			
//			System.out.flush();
//			
//		}
		
		/*
		for(int a = 'A'; a < 91; a++) {
			
			System.out.write(a);
			System.out.flush();
			
		}
		*/
		
		for( char i = 'A'; i <91; i++) {
			
			System.out.println(i);
			
		}
	}
	
}
