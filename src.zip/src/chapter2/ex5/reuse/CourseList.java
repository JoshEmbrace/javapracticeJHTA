package chapter2.ex5.reuse;

public class CourseList {
	Course[] courses;
	int current;
}
