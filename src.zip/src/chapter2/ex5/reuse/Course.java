package chapter2.ex5.reuse;

public class Course {
	int id;
	String name;
	int capacity;
	int groupCount;
	String[] members;
}
