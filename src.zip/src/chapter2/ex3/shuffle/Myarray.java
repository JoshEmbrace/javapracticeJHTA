package chapter2.ex3.shuffle;

public class Myarray {

	int id;
	String name;
	int capacity;
	int groupCount;
	String[] members;

}
