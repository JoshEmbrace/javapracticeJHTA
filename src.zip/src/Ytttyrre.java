
public class Ytttyrre {

	public static void main(String[] args) {
		for( int i=0; i<40; i++){
			
			if(i<20) {
			 	System.out.print(i+1);
			}
			
			if(19<i && i<40) {
			 	System.out.print(40-i);		 	
			}
			
		}
		
	}

}
