import java.util.Scanner;

public class ResRes {

	public static void main(String[] args) {
		
		
		int x = 0;
		
		Scanner scan = new Scanner(System.in);
		
		System.out.write(x);
		System.out.flush();
		

		x = x + scan.nextInt(); // ����ڰ� 3�� �Է���.System.out.println(x--);03

		scan.close();
		
	}

}
