
public class PrtcFor {

	public static void main(String[] args) {
		
//		for(int i = 0; i < 20; i++){
//		
//			if(i==4)
//			System.out.print("��");
//							  
//			else if(i%2==0)
//			System.out.print("��");
//
//			else
//		    System.out.print("��");
//	  
//				  
//		}
		
		/*
		for( int i=0; i<20; i++) {
			
			  System.out.print("��");
			  if(i==4)
				    System.out.print("��");
			  
		}
		*/
		/*
		for( int i=0; i<20; i++){
			if(i==4)
				System.out.print("��");
			else if(i%2==0)
			    System.out.print("��");
			else
			    System.out.print("��");
		}
		*/
		
//		for( int i=0; i<20; i++)
//			System.out.print(20-i);
		
		for(int i=0; i<40; i++){
			if(i<20)
				System.out.print(i+1);
			else
			    System.out.print(40-i);
		}
		
		/*
		for(int i = 0; i < 40; i++)
			
			if(i<20)
			System.out.print(i+1);
							  
			else
		    System.out.print(40-i);
	  
				  
		
		*/
		
		
//		for( int i=0; i<20; i++){
//			  System.out.print(i+1);
//			}
//
//		for( int i=0; i<20; i++){
//			  System.out.print(20-i);
//			}
		
		
		
		
		
	}

}
