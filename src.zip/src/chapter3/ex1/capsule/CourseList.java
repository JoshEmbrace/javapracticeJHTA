package chapter3.ex1.capsule;

public class CourseList {
	Course[] courses;
	int current;
}
