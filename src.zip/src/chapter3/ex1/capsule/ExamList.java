package chapter3.ex1.capsule;

public class ExamList {
	
	Exam[] list;
	int current;
	
}
