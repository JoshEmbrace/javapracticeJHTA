package chapter3.ex1.capsule;

public class Course {
	int id;
	String name;
	int capacity;
	int groupCount;
	String[] members;
}
