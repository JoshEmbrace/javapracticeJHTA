package chapter3.ex1.capsule;

public class Exam {
	
	int math;
	int eng;
	int kor;

}
