package chapter3.ex2.capsule;

public class Exam {
	
	int math;
	int eng;
	int kor;

}
