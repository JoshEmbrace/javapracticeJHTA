package chapter3.ex2.capsule;

public class Course {
	int id;
	String name;
	int capacity;
	int groupCount;
	String[] members;
}
