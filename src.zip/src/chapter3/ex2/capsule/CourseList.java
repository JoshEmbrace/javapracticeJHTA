package chapter3.ex2.capsule;

public class CourseList {
	Course[] courses;
	int current;
}
