package chapter3.ex4.test;

public class Exam {
	
	int math;
	int eng;
	int kor;

}
