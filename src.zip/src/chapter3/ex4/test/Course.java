package chapter3.ex4.test;

public class Course {
	int id;
	String name;
	int capacity;
	int groupCount;
	String[] members;
}
