package chapter3.ex3.oop;

public class CourseList {
	Course[] courses;
	int current;
}
