package chapter3.ex3.oop.hasa;

public class CourseList {
	Course[] courses;
	int current;
}
