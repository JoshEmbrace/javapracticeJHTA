package chapter3.ex3.oop;

public class Course {
	int id;
	String name;
	int capacity;
	int groupCount;
	String[] members;
}
