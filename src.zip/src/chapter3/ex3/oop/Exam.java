package chapter3.ex3.oop;

public class Exam {
	
	int math;
	int eng;
	int kor;

}
